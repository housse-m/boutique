import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-fixed',
  templateUrl: './theme-fixed.component.html',
  styleUrls: ['./theme-fixed.component.scss']
})
export class ThemeFixedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
