import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-other',
  templateUrl: './basic-other.component.html',
  styleUrls: ['./basic-other.component.scss']
})
export class BasicOtherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
